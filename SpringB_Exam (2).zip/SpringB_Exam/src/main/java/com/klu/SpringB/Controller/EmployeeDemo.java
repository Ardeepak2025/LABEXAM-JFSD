package com.klu.SpringB.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/SpringMVC")
public class EmployeeDemo {

    // 1. Display a simple greeting message
    @GetMapping("/welcome")
    public ModelAndView welcome() {
        ModelAndView modelAndView = new ModelAndView("welcome");
        modelAndView.addObject("message", "Welcome to Spring MVC!");
        return modelAndView;
    }

    // 2. Render a JSP file named "test"
    @GetMapping("/test")
    public ModelAndView test() {
        return new ModelAndView("test");
    }

    // 3. Display ID and name parameter values
    @GetMapping("/showInfo")
    public ModelAndView showInfo(@RequestParam("id") int id, @RequestParam("name") String name) {
        ModelAndView modelAndView = new ModelAndView("showInfo");
        modelAndView.addObject("id", id);
        modelAndView.addObject("name", name);
        return modelAndView;
    }

    // 4. Perform arithmetic operations
    @GetMapping("/calculateSum/{num1}/{num2}")
    public ModelAndView calculateSum(@PathVariable int num1, @PathVariable int num2) {
        ModelAndView modelAndView = new ModelAndView("calculateSum");
        modelAndView.addObject("sum", num1 + num2);
        modelAndView.addObject("difference", num1 - num2);
        modelAndView.addObject("product", num1 * num2);
        modelAndView.addObject("quotient", num1 / (double) num2);
        return modelAndView;
    }

    // 5. Display an Employee Form
    @GetMapping("/employeeForm")
    public ModelAndView employeeForm() {
        return new ModelAndView("employeeForm");
    }

    // 6. Add two numbers from the URL
    @GetMapping("/addNumbers")
    public ModelAndView addNumbers(@RequestParam("num1") int num1, @RequestParam("num2") int num2) {
        ModelAndView modelAndView = new ModelAndView("addNumbers");
        modelAndView.addObject("sum", num1 + num2);
        return modelAndView;
    }

    // 7. Combine two strings from the URL
    @GetMapping("/combine")
    public ModelAndView combineStrings(@RequestParam("str1") String str1, @RequestParam("str2") String str2) {
        ModelAndView modelAndView = new ModelAndView("combine");
        modelAndView.addObject("result", str1 + " " + str2);
        return modelAndView;
    }

    // 8. Perform addition and multiplication
    @GetMapping("/calculate")
    public ModelAndView calculate(@RequestParam("num1") int num1, @RequestParam("num2") int num2) {
        ModelAndView modelAndView = new ModelAndView("calculate");
        modelAndView.addObject("sum", num1 + num2);
        modelAndView.addObject("product", num1 * num2);
        return modelAndView;
    }
}
